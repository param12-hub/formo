Put hairstyle reference photos in this folder.
Suggested naming: style-name-front.jpg, style-name-side.jpg, style-name-back.jpg.
The current prototype's Admin upload stores selected photo data in browser storage; it does not automatically scan this folder.
