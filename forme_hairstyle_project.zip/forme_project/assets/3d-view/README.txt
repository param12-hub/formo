Put hairstyle 3D model files in this folder (.glb, .gltf, .obj, .stl).
Suggested naming: style-name.glb.
The current prototype records the uploaded model filename but does not render model geometry yet; a WebGL/Three.js loader is required.
