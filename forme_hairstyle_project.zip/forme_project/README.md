# FORME — Men's Hairstyle Reference App

A responsive, no-login HTML prototype for browsing men's hairstyles, comparing front/side/back reference photos, and preparing barber instructions.

## Project folders

- `assets/images/` — keep hairstyle reference photos here. Recommended names: `textured-crop-front.jpg`, `textured-crop-side.jpg`, `textured-crop-back.jpg`.
- `assets/3d-view/` — keep separate 3D model files here (`.glb`, `.gltf`, `.obj`, or `.stl`). Recommended names: `textured-crop.glb`.
- `index.html` — the app.

Both asset folders contain a README so the folders remain visible in file managers and version control even before you add assets.

## Search

The search box now searches across the hairstyle name and other descriptive fields, including the description, barber instructions, category, texture, sides/fade/taper details, length, finish, maintenance notes, tags, and uploaded asset filenames. For multi-word searches, every typed word must match somewhere in the searchable text. Example: `low fade curly`.

## Important asset-storage note

This is a standalone browser prototype. Files selected through the Admin upload form are currently stored as browser-local data (photos) and a filename record (3D model); the browser cannot silently copy uploads into the project folders. Put original files in the folders above to keep them organized in the project. The app's Admin form can still be used to attach photo data for this browser.

The current prototype does not render uploaded 3D geometry yet. A Three.js/WebGL loader and model-serving path are needed to display actual `.glb`/`.gltf`/`.obj` geometry in the 3D tab.

## Run

Open `index.html` in a modern browser. For best local asset-path behavior as the project grows, run a local static server from this folder, for example `python -m http.server 8000`, then visit `http://localhost:8000`.
